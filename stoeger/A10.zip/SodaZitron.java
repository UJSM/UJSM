package stoeger;
/**
 * SodaZitron abgeleitet von Getraenk
 * @author Michael Stoeger
 * @version 03122013
 */
public class SodaZitron extends Getraenk {
	private double preis = 1.5; //Preis
	@Override
	/**
	 * {@link Getraenk#preis()}
	 */
	public double preis() {
		return preis;
	}
	@Override
	/**
	 * {@link Getraenk#toString()}
	 */
	public String toString(){
		return "Soda Zitron";
	}
	/**
	 * Nichts zu setzen
	 */
	public SodaZitron(){}
}
