package stoeger;
/**
 * Kaffeeklasse die von Getraenk erbt
 * @author Michael Stoeger
 * @version 03122013
 */
public class Kaffee extends Getraenk {
	private static final double gpreis = 2.5; //Grundpreis
	private static final double gzucker = 0.2; //Preis von Zucker
	private static final double gmilch = 0.3; //Preis von Milch
	private boolean zucker;
	private boolean milch;
	@Override
	/**
	 * {@link Getraenk#preis()}
	 */
	public double preis() {
		double preis = gpreis;
		if(zucker)
			preis+=gzucker;
		if(milch)
			preis+=gmilch;
		return preis;
	}
	@Override
	/**
	 * {@link Getraenk#toString()}
	 */
	public String toString(){
		String s = "Kaffee";
		if(milch&&zucker)
			s+=" mit Milch und Zucker";
		else if(milch)
			s+=" mit Milch";
		else if(zucker)
			s+=" mit Zucker";
		else
			s+=" schwarz";
		return s;
	}
	/**
	 * Konstruktor mit Milch und Zucker
	 * @param zucker
	 * @param milch
	 */
	public Kaffee(boolean zucker,boolean milch){
		this.zucker=zucker;
		this.milch=milch;
	}
	/**
	 * Standardkonstruktor
	 */
	public Kaffee(){
		this(false,false);
	}
	/**
	 * Getter fuer Grundpreis
	 * @return preis -> float
	 */
	public static double getGpreis() {
		return gpreis;
	}
	/**
	 * Getter fuer Zuckerpreis
	 * @return zucker -> float
	 */
	public static double getGzucker() {
		return gzucker;
	}
	/**
	 * Getter fuer Milchpreis
	 * @return
	 */
	public static double getGmilch() {
		return gmilch;
	}
	/**
	 * Zucker ja/nein
	 * @return zucker
	 */
	public boolean isZucker() {
		return zucker;
	}
	/**
	 * Milch ja/nein
	 * @return milch
	 */
	public boolean isMilch() {
		return milch;
	}
}
