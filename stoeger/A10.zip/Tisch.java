package stoeger;
/**
 * Tisch fuer all die Getraenke
 * @author Michael Stoeger
 * @version 03122013
 */
public class Tisch{
	private Getraenk[] t; //Tisch
	/**
	 * Main Methode -> zum Testen
	 * @param args
	 */
	public static void main(String[] x) {
		Tisch a = new Tisch(7);
		a.testBestellung();
		a.rechnung();
	}
	/**
	 * Konstruktor fuer einen Tisch
	 * @param plaetze -> int
	 */
	public Tisch(int plaetze){
		t= new Getraenk[plaetze];
	}
	/**
	 * Bestellt zufallsgenerierte Testgetraenke
	 */
	public void testBestellung(){
		for(int i = 0;i<t.length;i++){ //Solange Plaetze frei sind
			int x = (int) (Math.random()*2);
			boolean kaffee = false;
			if(x==0) //Is es ein Kaffee
				kaffee = true;
			else
				kaffee = false;
			if(kaffee){ //Fuer Kaffeezutaten
				boolean zucker =false;
				x = (int) (Math.random()*2);
				if(x==0) //Ist Zucker dabei
					zucker = true;
				x = (int) (Math.random()*2);
				boolean milch = false;
				if(x==0) //Mit Milch??
					milch = true;
				t[i] = new Kaffee(zucker,milch); //Kaffee generieren
			}
			else
				t[i] = new SodaZitron(); //Sonst Soda Zitron generieren
		}
	}
	/**
	 * Gibt die Rechnung aus
	 */
	public void rechnung(){
		float rechnung =0;
		for(int i = 0;i<t.length;i++){
			System.out.println(t[i]+": "+t[i].preis()+"�"); //Getraenk und Preis ausgeben
			rechnung+=t[i].preis(); //Zusammenrechnen
		}
		System.out.println("-------------------------");
		System.out.println("Gesamt: "+rechnung+"�"); //Gesamtbetrag ausgeben
	}
}
