package stoeger;
/**
 * Abstrakte Klasse fuer Getraenke in A10
 * @author Michael Stoeger
 * @version 03122013
 */
public abstract class Getraenk {
	/**
	 * Gibt den Preis des Getraenks zurueck
	 * @return preis -> double
	 */
	public abstract double preis();
	@Override
	/**
	 * Wandelt das Objekt in einen ausgebbaren String um
	 */
	public String toString(){
		System.out.println("Error");
		return null;
	}
}
