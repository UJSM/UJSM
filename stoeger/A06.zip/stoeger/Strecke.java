package stoeger;

/**
 * Strecke abgeleitet von Punkt
 * @author Michael St�ger
 * @version 4.11.2013
 */
public class Strecke extends Punkt {
	private double x2;
	private double y2;
	/**
	 * @return Strecke
	 */
	public double streckeberechnen(){
		double a = getX() -x2;
		double b = getY() -y2;
		if(a<0) //a negativ
			a*=-1;
		if(b<0)
			b*=-1;
		return Math.sqrt(a*a+b*b);
	}
	/**
	 * @return x2
	 */
	public double getX2() {
		return x2;
	}
	/**
	 * @param x2
	 */
	public void setX2(double x2) {
		this.x2 = x2;
	}
	/**
	 * @return y2
	 */
	public double getY2() {
		return y2;
	}
	/**
	 * @param y2
	 */
	public void setY2(double y2) {
		this.y2 = y2;
	}
	/**
	 * Konstruktor mit vollem Funktionsumfang
	 * @param x2
	 * @param y2
	 */
	public Strecke(double x2,double y2){
		this.x2=x2;
		this.y2=y2;
	}
	/**
	 * @param x2
	 */
	public Strecke(double x2){
		this(x2,0);
	}
	/**
	 * Standardkonstruktor
	 */
	public Strecke(){
		this(0,0);
	}
}
