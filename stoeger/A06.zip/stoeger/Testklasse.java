package stoeger;

/**
 * Testklasse f�r A06
 * @author Michael St�ger
 * @version 4.11.2013
 */
public class Testklasse {
	/**
	 * zum Testmothoden aufrufen
	 */
	public static void main(String[] args){
		TestKreis();
		TestPunkt();
		TestQuadrat();
		TestStrecke();
	}
	/**
	 * Kreis Testen
	 */
	public static void TestKreis(){
		System.out.println("**Kreis**");
		Kreis a = new Kreis(5);
		System.out.println("Radius = 5");
		System.out.println("Umfang = "+a.umfang()+".");
		System.out.println("Flaecheninhalt = "+a.flaecheninhalt()+".");
		System.out.println("**Kreis**");
	}
	/**
	 * Punkt Testen
	 */
	public static void TestPunkt(){
		System.out.println("**Punkt**");
		Punkt a = new Punkt(1,1);
		System.out.println("x = "+a.getX()+".");
		System.out.println("y = "+a.getY()+".");
		System.out.println("**Punkt**");
	}
	/**
	 * Quadrat Testen
	 */
	public static void TestQuadrat(){
		System.out.println("**Quadrat**");
		Quadrat a = new Quadrat(5);
		System.out.println("Seitenlaenge = 5");
		System.out.println("Flaecheninhalt = "+a.flaecheninhalt()+".");
		System.out.println("Umfang = "+a.umfang()+".");
		System.out.println("**Quadrat**");
	}
	/**
	 * Strecke Testen
	 */
	public static void TestStrecke(){
		System.out.println("**Strecke**");
		Strecke a = new Strecke(5,0);
		System.out.println("Streckenlaenge = "+a.streckeberechnen()+".");
		System.out.println("**Strecke**");
	}
}
