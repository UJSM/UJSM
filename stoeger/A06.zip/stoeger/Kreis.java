package stoeger;

/**
 * Kreis abgeleitet von Punkt
 * @author Michael St�ger
 * @version 4.11.2013
 */
public class Kreis extends Punkt {
	private double radius;
	/**
	 * @return umfang
	 */
	public double umfang(){
		 return Math.PI*2*radius;
	}
	/**
	 * @return flaecheninhalt
	 */
	public double flaecheninhalt(){
		return Math.PI*radius*radius;
	}
	/**
	 * @return radius
	 */
	public double getRadius() {
		return radius;
	}
	/**
	 * @param radius
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}
	/**
	 * @param radius
	 */
	public Kreis(double radius){
		this.radius=radius;
	}
	/**
	 * Standardkonstruktor
	 */
	public Kreis(){
		this(0);
	}
}
