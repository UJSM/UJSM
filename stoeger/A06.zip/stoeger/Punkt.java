package stoeger;

/**
 * Punkt Superklasse
 * @author Michael St�ger
 * @version 4.11.2013
 */
public class Punkt {
	private double x;
	private double y;
	/**
	 * @return x
	 */
	public double getX() {
		return x;
	}
	/**
	 * @param x
	 */
	public void setX(double x) {
		this.x = x;
	}
	/**
	 * @return y
	 */
	public double getY() {
		return y;
	}
	/**
	 * @param y
	 */
	public void setY(double y) {
		this.y = y;
	}
	/**
	 * @param x
	 * @param y
	 */
	public Punkt(double x,double y){
		this.y=y;
		this.x=x;
	}
	/**
	 * @param x
	 */
	public Punkt(double x){
		this(x,0);
	}
	/**
	 * Standardkonstruktor
	 */
	public Punkt(){
		this(0,0);
	}
}
