package stoeger;

/**
 * Quadrat abgeleitet von Punkt
 * Punkt MUSS links unten sein
 * @author Michael St�ger
 * @version 4.11.2013
 */
public class Quadrat extends Punkt {
	private double seitenlaenge;
	/**
	 * @return flaecheninhalt
	 */
	public double flaecheninhalt(){
		return seitenlaenge*seitenlaenge;
	}
	/**
	 * @return umfang
	 */
	public double umfang(){
		return 4*seitenlaenge;
	}
	/**
	 * Standardkonstruktor
	 */
	public Quadrat(){
		this(0);
	}
	/**
	 * @param seitenlaenge
	 */
	public Quadrat(double seitenlange){
		super();
		this.seitenlaenge=seitenlange;
	}
}
