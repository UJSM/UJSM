package stoeger;
/**
 * Cappuccino Klasse die Kaffee implementiert
 * @author Michael Stoeger
 * @version 01122013
 */
public class Cappuccino implements Kaffee{
	private static float preis = 3; //Hier Preis einstellen
	@Override
	/**
	 * {@link Kaffee#preis()}
	 */
	public float preis() {
		return preis;
	}
	@Override
	/**
	 * {@link Kaffee#toString()}
	 */
	public String toString(){
		return "Cappuccino";
	}
	/**
	 * Nichts einzustellen
	 */
	public Cappuccino(){}
}
