package stoeger;
/**
 * Testklasse fier Kaffee
 * @author Michael Stoeger
 * @version 01122013
 */
public class Testklasse {
	/**
	 * Testmethode fuer Kaffee
	 * @param x
	 */
	public static void main(String[] x){
		Kaffee[] c = new Kaffee[2];
		c[0] = new Cappuccino();
		c[1] = new Espresso();
		for(int i = 0;i<c.length;i++){
			System.out.println(c[i] + ": "+c[i].preis());
		}
	}
}