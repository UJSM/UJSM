package stoeger;
/**
 * Espresso Klasse die Kaffee implementiert
 * @author Michael Stoeger
 * @version 01122013
 */
public class Espresso implements Kaffee{
	private static float preis = (float) 2.50; //Hier Preis einstellen
	@Override
	/**
	 * {@link Kaffee#preis()}
	 */
	public float preis() {
		return preis;
	}
	@Override
	/**
	 * {@link Kaffee#toString()}
	 */
	public String toString(){
		return "Espresso";
	}
	/**
	 * Nichts einzustellen
	 */
	public Espresso(){}
}
