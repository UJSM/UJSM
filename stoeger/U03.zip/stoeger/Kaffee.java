package stoeger;
/**
 * Interface fuer Kaffeesorten
 * @author Michael Stoeger
 * @version 25.11.2013
 */
public interface Kaffee {
	/**
	 * Gibt den Preis des Kaffees zurueck
	 * @return preis -> float
	 */
	public float preis();
	/**
	 * Gibt den Namen des Kaffees zurueck
	 * @return name -> String
	 */
	public String toString();
}
