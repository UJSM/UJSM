package stoeger;
/**
 * Diese Klasse ist fuer das Testen von Vehicle und dessen Unterklassen zust�ndig
 * @author Michael St�ger
 * @version 27.10.2013
 */
public class Testklasse {
	/**
	 * Main Methode
	 * Ruft Testmethoden auf
	 * @param args
	 */
	public static void main(String[] args){
		Vehicletest();
		Autotest();
		Fahrradtest();
		Kutschetest();
	}
	/**
	 * Testet Vehicle
	 */
	public static void Vehicletest(){
		System.out.println("-------Vehicle Test Anfang-------");
		Vehicle a = new Vehicle();
		a.print();
		a.setBrand("VW");
		a.move();
		a.lightson();
		a.damage();
		a.movein(2);
		a.changedir('r');
		a.print();
		System.out.println("-------Vehicle Test Ende---------");
	}
	/**
	 * Testet Auto
	 */
	public static void Autotest(){
		System.out.println("-------Auto Test Anfang-------");
		Auto a = new Auto();
		a.print();
		a.setColor("Rot");
		a.setDoors(5);
		a.opendoors();
		a.setMaxspeed(150);
		a.setPs(100);
		a.setZylinder(5);
		a.print();
		System.out.println("--------Auto Test Ende ------");
	}
	/**
	 * Testet Fahrrad
	 */
	public static void Fahrradtest(){
		System.out.println("-------Fahrrad Test Anfang-------");
		Fahrrad a = new Fahrrad();
		a.print();
		a.setKinderrad(true);
		a.setSitzhoehe(5);
		a.treten();
		a.hochschalten();
		a.print();
		System.out.println("--------Fahrrad Test Ende ------");
	}
	/**
	 * Testet Kutsche
	 */
	public static void Kutschetest(){
		System.out.println("-------Kutsche Test Anfang-------");
		Kutsche a = new Kutsche();
		a.print();
		a.setBaujahr(1980);
		a.setDach(true);
		a.setMaterial("Holz");
		a.setPferde(4);
		a.setPlaetze(8);
		a.setZusatzbremse(true);
		a.print();
		System.out.println("--------Kutsche Test Ende ------");
	}
}
