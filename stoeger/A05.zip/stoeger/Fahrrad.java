package stoeger;
/**
 * Abgeleitete Klasse von Vehicle
 * Demo f�r Vererbung
 * @author Michael St�ger
 * @version 26.10.2013
 */
public class Fahrrad extends Vehicle{
	private boolean treten; //wird getreten
	private double sitzhoehe;
	private int felgendurchmesser;
	private boolean kinderrad;
	private boolean damenrad;
	private int gang;
	/**
	 * Bestimmte anzahl an g�ngen hochschalten
	 * @param hoch
	 */
	public void hochschalten(int hoch){
		gang+=hoch;
	}
	/**
	 * einen gang hoch
	 */
	public void hochschalten(){
		this.hochschalten(1);
	}
	/**
	 * Bestimmte Anzahl an Gaengen runterschalten
	 * @param runter
	 */
	public void runterschalten(int runter){
		if(runter>gang) //Kann ich so viele Gaenge runterschalten
			gang=0;
		else
			gang-=runter;
	}
	/**
	 * Einen Gang runterschalten
	 */
	public void runterschalten(){
		this.runterschalten(1);
	}
	/**
	 * Zu treten beginnen
	 */
	public void treten(){
		treten=true;
		super.move();
	}
	/**
	 * Aufh�ren zu treten
	 */
	public void stop(){
		treten=false;
		super.stop(); //Das Fahrrad k�nnte sich auch bewegen wenn man nicht tritt
	}
	/**
	 * @return sitzhoehe
	 */
	public double getSitzhoehe() {
		return sitzhoehe;
	}
	/**
	 * Sitzhoehe einstellen
	 * @param sitzhoehe
	 */
	public void setSitzhoehe(double sitzhoehe) {
		this.sitzhoehe = sitzhoehe;
	}
	/**
	 * @return Falgendurchmesser
	 */
	public int getFelgendurchmesser() {
		return felgendurchmesser;
	}
	/**
	 * Felgendurchmesser einstellen
	 * @param felgendurchmesser
	 */
	public void setFelgendurchmesser(int felgendurchmesser) {
		this.felgendurchmesser = felgendurchmesser;
	}
	/**
	 * @return kinderrad?
	 */
	public boolean getKinderrad() {
		return kinderrad;
	}
	/**
	 * Ist es ein Kinderrad
	 * @param kinderrad
	 */
	public void setKinderrad(boolean kinderrad) {
		this.kinderrad = kinderrad;
	}
	/**
	 * @return damenrad?
	 */
	public boolean getDamenrad() {
		return damenrad;
	}
	/**
	 * Ist es ein Damenrad
	 * @param damenrad
	 */
	public void setDamenrad(boolean damenrad) {
		this.damenrad = damenrad;
	}
	/**
	 * @return wird getreten?
	 */
	public boolean getTreten() {
		return treten;
	}
	/**
	 * @return gang
	 */
	public int getGang() {
		return gang;
	}
	/**
	 * Konstruktor mit allen Attributen
	 * @param treten
	 * @param sitzhoehe
	 * @param felgendurchmesser
	 * @param kinderrad
	 * @param damenrad
	 * @param gang
	 */
	public Fahrrad(boolean treten, double sitzhoehe, int felgendurchmesser, boolean kinderrad, boolean damenrad, int gang) {
		super();
		this.treten = treten;
		this.sitzhoehe = sitzhoehe;
		this.felgendurchmesser = felgendurchmesser;
		this.kinderrad = kinderrad;
		this.damenrad = damenrad;
		this.gang = gang;
	}
	/**
	 * Konstruktor ohne gang
	 * @param treten
	 * @param sitzhoehe
	 * @param felgendurchmesser
	 * @param kinderrad
	 * @param damenrad
	 */
	public Fahrrad(boolean treten, double sitzhoehe, int felgendurchmesser, boolean kinderrad, boolean damenrad){
		this(treten,sitzhoehe,felgendurchmesser,kinderrad,damenrad,0);
	}
	/**
	 * Konstruktor ohne gang und damenrad
	 * @param treten
	 * @param sitzhoehe
	 * @param felgendurchmesser
	 * @param kinderrad
	 */
	public Fahrrad(boolean treten, double sitzhoehe, int felgendurchmesser, boolean kinderrad){
		this(treten,sitzhoehe,felgendurchmesser,kinderrad,false,0);
	}
	/**
	 * Konstruktor mit treten,sitzhoehe,felgendurchmesser
	 * @param treten
	 * @param sitzhoehe
	 * @param felgendurchmesser
	 */
	public Fahrrad(boolean treten, double sitzhoehe, int felgendurchmesser){
		this(treten,sitzhoehe,felgendurchmesser,false,false,0);
	}
	/**
	 * Konstruktor mit treten, sitzhoehe
	 * @param treten
	 * @param sitzhoehe
	 */
	public Fahrrad(boolean treten, double sitzhoehe){
		this(treten,sitzhoehe,17,false,false,0);
	}
	/**
	 * Konstruktor mit treten
	 * @param treten
	 */
	public Fahrrad(boolean treten){
		this(treten,0,17,false,false,0);
	}
	/**
	 * Standardkonstruktor
	 */
	public Fahrrad(){
		this(false,0,17,false,false,0);
	}
	@Override
	/**
	 * Erweitert die Printmethode der Superklasse
	 * Gibt Informationen �ber das Fahrrad aus
	 */
	public void print(){
		super.print();
		if(treten==true)  //wird getreten
			System.out.println("Es wird getreten.");
		else
			System.out.println("Es wird nicht getreten.");
		if(damenrad==true)
			System.out.println("Es ist ein Damenrad.");
		else //Wenn es kein Damenrad ist ist es vll ein Kinderrad
			if(kinderrad==true)
				System.out.println("Es ist ein Kinderrad.");
			else
				System.out.println("Es ist weder ein Kinder, noch ein Damenrad.");
		System.out.println("Im Moment ist der "+gang+". Gang eingestellt.");
		System.out.println("Die Sitzhoehe betr�gt "+sitzhoehe+".");
		System.out.println("Der Felgendurchmesser betr�gt "+felgendurchmesser+" Zoll.");
		System.out.println("********************");
	}
}
