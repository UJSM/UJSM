package stoeger;
/**
 * Grund Vehicle Klasse
 * Demo f�r Vererbung
 * @author Michael St�ger
 * @version 25.10.2013
 */
public class Vehicle {
	private boolean ismoving; //bewegt sich das Fahrzeug
	private char dir; //in welche Richtung
	private int personsinside; //Wie viele Personen sind drin
	private String brand; //Welche Marke
	private boolean damaged; //Ist es besch�digt
	private boolean lightson; //Sind die Lichter an
	/**
	 * @return ismoving
	 */
	public boolean getIsmoving() {
		return ismoving;
	}
	/**
	 * Konstruktor mit den meisten Attributen
	 * @param ismoving
	 * @param dir
	 * @param personsinside
	 * @param brand
	 * @param damaged
	 * @param lightson
	 */
	public Vehicle(boolean ismoving, char dir, int personsinside, String brand, boolean damaged, boolean lightson) {
		this.ismoving = ismoving;
		this.dir = dir;
		this.personsinside = personsinside;
		this.brand = brand;
		this.damaged = damaged;
		this.lightson = lightson;
	}
	/**
	 * Konstruktor ohne lightson
	 * @param ismoving
	 * @param dir
	 * @param personsinside
	 * @param brand
	 * @param damaged
	 */
	public Vehicle(boolean ismoving, char dir, int personsinside, String brand, boolean damaged) {
		this(ismoving,dir,personsinside,brand,damaged,false);
	}
	/**
	 * Konstruktor ohne lightson,damaged
	 * @param ismoving
	 * @param dir
	 * @param personsinside
	 * @param brand
	 */
	public Vehicle(boolean ismoving, char dir, int personsinside, String brand) {
		this(ismoving,dir,personsinside,brand,false,false);
	}
	/**
	 * Konstruktor ohne lightson,damaged,brand
	 * @param ismoving
	 * @param dir
	 * @param personsinside
	 */
	public Vehicle(boolean ismoving, char dir, int personsinside) {
		this(ismoving,dir,personsinside,"",false,false);
	}
	/**
	 * Konstruktor nur mit ismoving,richtung
	 * @param ismoving
	 * @param dir
	 */
	public Vehicle(boolean ismoving, char dir) {
		this(ismoving,dir,0,"",false,false);
	}
	/**
	 * Konstruktor nur mit ismoving
	 * @param ismoving
	 */
	public Vehicle(boolean ismoving) {
		this(ismoving,'f',0,"",false,false);
	}
	/**
	 * Standardkonstruktor
	 */
	public Vehicle() {
		this(false,'f',0,"",false,false);
	}
	/**
	 * Bewegt das Fahrzeug
	 */
	public void move(){
		ismoving=true;
	}
	/**
	 * Stoppt das Fahrzeug
	 */
	public void stop(){
		ismoving=false;
	}
	/**
	 * Richtung wechseln
	 * @param newdir
	 */
	public void changedir(char newdir){
		if(newdir=='f'||newdir=='b'||newdir=='l'||newdir=='r')
			dir=newdir;
		else{
			ismoving=false;
			dir='f';
		}
	}
	/**
	 * Personen steigen ein
	 * @param in
	 */
	public void movein(int in){
		personsinside+=in;
	}
	/**
	 * Eine Person steigt ein
	 */
	public void movein(){
		this.movein(1);
	}
	/**
	 * Personen steigen aus
	 * @param out
	 */
	public void moveout(int out){
		if(out>personsinside) //K�nnen so viele Personen aussteigen
			personsinside=0;
		else
			personsinside-=out;
	}
	/**
	 * Eine Person steigt aus
	 */
	public void moveout(){
		this.moveout(1);
	}
	/**
	 * Das Fahrzeug besch�digen
	 */
	public void damage(){
		damaged=true;
	}
	/**
	 * Das Fahrzeug reparieren
	 */
	public void repair(){
		damaged=false;
	}
	/**
	 * Lichter einschalten
	 */
	public void lightson(){
		lightson=true;
	}
	/**
	 * Lichter ausschalten
	 */
	public void lightsoff(){
		lightson=false;
	}
	/**
	 * Marke holen
	 * @return marke
	 */
	public String getBrand() {
		return brand;
	}
	/**
	 * Marke setzen
	 * @param brand
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}
	/**
	 * Infos �ber das Fahrzeug ausgeben
	 */
	public void print(){
		if(ismoving==true){
			System.out.println("Das Fahrzeug bewegt sich!");
			if(dir=='f')
				System.out.println("Es f�hrt nach vorne");
			else if(dir=='b')
				System.out.println("Es f�hrt nach hinten");
			else if(dir=='r')
				System.out.println("Es f�hrt nach rechts");
			else if(dir=='l')
				System.out.println("Es f�hrt nach links");
			}
		if(ismoving==false)
			System.out.println("Das Fahrzeug bewegt sich nicht!");
		System.out.println("Es befinden sich "+personsinside+" im Fahrzeug.");
		System.out.println("Die Marke des Fahrzeugs ist: "+brand+".");
		if(damaged==true)
			System.out.println("Das Fahrzeug ist besch�digt.");
		if(lightson==true)
			System.out.println("Die Lichter leuchten.");
		else
			System.out.println("Die Lichter sind aus.");
		System.out.println("-");
	}
}
