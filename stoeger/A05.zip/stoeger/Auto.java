package stoeger;
/**
 * Abgeleitete Klasse Auto
 * von Vehicle abgeleitet
 * @author Michael St�ger
 * @version 25.10.2013
 */
public class Auto extends Vehicle{
	private int doors; //T�ren
	private String color; //Lackfarbe
	private int ps;
	private int zylinder;
	private int maxspeed;
	private boolean doorsclosed; //Sind die T�ren geschlossen
	/**
	 * Konstruktor mit allen Attributen
	 * @param doors
	 * @param color
	 * @param ps
	 * @param zylinder
	 * @param maxspeed
	 * @param doorsclosed
	 */
	public Auto(int doors, String color, int ps, int zylinder, int maxspeed, boolean doorsclosed) {
		super(); //Immer nur Standard, da sonst zu viele m�glichkeiten
		this.doors = doors;
		this.color = color;
		this.ps = ps;
		this.zylinder = zylinder;
		this.maxspeed = maxspeed;
		this.doorsclosed = doorsclosed;
	}
	/**
	 * Konstruktor ohne doorsclosed
	 * @param doors
	 * @param color
	 * @param ps
	 * @param zylinder
	 * @param maxspeed
	 */
	public Auto(int doors, String color, int ps, int zylinder, int maxspeed){
		this(doors,color,ps,zylinder,maxspeed,true);
	}
	/**
	 * Konstruktor ohne doorsclosed, maxspeed
	 * @param doors
	 * @param color
	 * @param ps
	 * @param zylinder
	 */
	public Auto(int doors, String color, int ps, int zylinder){
		this(doors,color,ps,zylinder,0,true);
	}
	/**
	 * Konstruktor mit doors,color,ps
	 * @param doors
	 * @param color
	 * @param ps
	 */
	public Auto(int doors, String color, int ps){
		this(doors,color,ps,1,0,true);
	}
	/**
	 * Konstruktor mit doors, color
	 * @param doors
	 * @param color
	 */
	public Auto(int doors, String color){
		this(doors,color,1,1,0,true);
	}
	/**
	 * Konstruktor mit doors
	 * @param doors
	 */
	public Auto(int doors){
		this(doors,"",1,1,0,true);
	}
	/**
	 * Standardkonstruktor
	 */
	public Auto(){
		this(1,"",1,1,0,true);
	}
	/**
	 * T�ren schlie�en
	 */
	public void closedoors(){
		doorsclosed=true;
	}
	/**
	 * Tueren �ffnen
	 */
	public void opendoors(){
		doorsclosed=false;
	}
	/**
	 * @return tueren
	 */
	public int getDoors() {
		return doors;
	}
	/**
	 * Tueren setzen
	 * @param doors
	 */
	public void setDoors(int doors) {
		this.doors = doors;
	}
	/**
	 * @return color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * Farbe setzen
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return ps
	 */
	public int getPs() {
		return ps;
	}
	/**
	 * PS setzen
	 * @param ps
	 */
	public void setPs(int ps) {
		this.ps = ps;
	}
	/**
	 * @return zylinder
	 */
	public int getZylinder() {
		return zylinder;
	}
	/**
	 * Zylinder setzen
	 * @param zylinder
	 */
	public void setZylinder(int zylinder) {
		this.zylinder = zylinder;
	}
	/**
	 * @return maxspeed
	 */
	public int getMaxspeed() {
		return maxspeed;
	}
	/**
	 * Maxspeed setzen
	 * @param maxspeed
	 */
	public void setMaxspeed(int maxspeed) {
		this.maxspeed = maxspeed;
	}
	/**
	 * Infos �ber das Auto ausgeben
	 */
	@Override //�berschreiben
	public void print(){
		super.print();
		System.out.println("Das Auto hat "+doors+" T�ren.");
		System.out.println("Das Auto ist "+color+".");
		System.out.println("Das Auto hat "+ps+"ps.");
		System.out.println("Das Auto hat "+zylinder+" Zylinder.");
		System.out.println("Das Auto kann maximal "+maxspeed+"km/h fahren.");
		if(doorsclosed==true)
			System.out.println("Die T�ren sind geschlossen.");
		else
			System.out.println("Die T�ren sind offen.");
		System.out.println("********************");
	}
}
