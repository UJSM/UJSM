package stoeger;
/**
 * Abgeleitete Klasse von Vehicle
 * Demo zu Vererbung
 * @author Michael St�ger
 * @version 25.10.2013
 */
public class Kutsche extends Vehicle{
	private String material;
	private int pferde;
	private boolean dach;
	private int plaetze;
	private boolean zusatzbremse;
	private int baujahr;
	/**
	 * Konstruktor mit allen Attributen
	 * @param material
	 * @param pferde
	 * @param dach
	 * @param plaetze
	 * @param zusatzbremse
	 * @param baujahr
	 */
	public Kutsche(String material, int pferde, boolean dach, int plaetze, boolean zusatzbremse, int baujahr) {
		super();
		this.material = material;
		this.pferde = pferde;
		this.dach = dach;
		this.plaetze = plaetze;
		this.zusatzbremse = zusatzbremse;
		this.baujahr = baujahr;
	}
	/**
	 * Konstruktor ohne Baujahr
	 * @param material
	 * @param pferde
	 * @param dach
	 * @param plaetze
	 * @param zusatzbremse
	 */
	public Kutsche(String material, int pferde, boolean dach, int plaetze, boolean zusatzbremse){
		this(material,pferde,dach,plaetze,zusatzbremse,2000);
	}
	/**
	 * Konstruktor ohne Bauplatz und Zusatzbremse
	 * @param material
	 * @param pferde
	 * @param dach
	 * @param plaetze
	 */
	public Kutsche(String material, int pferde, boolean dach, int plaetze){
		this(material,pferde,dach,plaetze,false,2000);
	}
	/**
	 * Konstruktor ohne Bauplatz,bremse,plaetze
	 * @param material
	 * @param pferde
	 * @param dach
	 */
	public Kutsche(String material, int pferde, boolean dach){
		this(material,pferde,dach,1,false,2000);
	}
	/**
	 * Konstruktor mit material,pferde
	 * @param material
	 * @param pferde
	 */
	public Kutsche(String material, int pferde){
		this(material,pferde,false,1,false,2000);
	}
	/**
	 * Konstruktor nur mit material
	 * @param material
	 */
	public Kutsche(String material){
		this(material,1,false,1,false,2000);
	}
	/**
	 * Standardkonstruktor
	 */
	public Kutsche(){
		this("",1,false,1,false,2000);
	}
	/**
	 * @return material
	 */
	public String getMaterial() {
		return material;
	}
	/**
	 * @param material
	 */
	public void setMaterial(String material) {
		this.material = material;
	}
	/**
	 * @return pferde
	 */
	public int getPferde() {
		return pferde;
	}
	/**
	 * @param pferde
	 */
	public void setPferde(int pferde) {
		this.pferde = pferde;
	}
	/**
	 * @return dach
	 */
	public boolean getDach() {
		return dach;
	}
	/**
	 * @param dach
	 */
	public void setDach(boolean dach) {
		this.dach = dach;
	}
	/**
	 * @return plaetze
	 */
	public int getPlaetze() {
		return plaetze;
	}
	/**
	 * @param plaetze
	 */
	public void setPlaetze(int plaetze) {
		this.plaetze = plaetze;
	}
	/**
	 * @return zusatzbremse
	 */
	public boolean getZusatzbremse() {
		return zusatzbremse;
	}
	/**
	 * @param zusatzbremse
	 */
	public void setZusatzbremse(boolean zusatzbremse) {
		this.zusatzbremse = zusatzbremse;
	}
	/**
	 * @return baujahr
	 */
	public int getBaujahr() {
		return baujahr;
	}
	/**
	 * @param baujahr
	 */
	public void setBaujahr(int baujahr) {
		this.baujahr = baujahr;
	}
	@Override
	/**
	 * Gibt Informationen �ber die Kutsche aus
	 */
	public void print(){
		super.print();
		System.out.println("Diese Kutsche wurde im Jahr "+baujahr+" gebaut.");
		if(dach==true)
			System.out.println("Diese Kutsche hat ein Dach.");
		else
			System.out.println("Diese Kutsche hat kein Dach.");
		System.out.println("Diese Kutsche ist aus "+material+".");
		System.out.println("Diese Kutsche hat "+pferde+" Pferde.");
		System.out.println("Diese Kutsche hat "+plaetze+" Sitzplaetze.");
		if(zusatzbremse==true)
			System.out.println("Diese Kutsche hat eine Zustatzbremse.");
		else
			System.out.println("Diese Kutsche hat keine Zusatzbremse.");
		System.out.println("********************");
	}
}
