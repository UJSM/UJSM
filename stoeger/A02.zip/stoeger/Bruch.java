package stoeger;

/**
 * Eine Klasse fuer den Umgang mit Br�chen
 * @author Michael St�ger
 * @version 3.10.2013
 */
public class Bruch {
	private int zaehler;
	private int nenner;
	/**
	 * Eine ganze Zahl hinzuf�gen
	 * @param Zahl
	 */
	public void add(int zaehler){
		this.add(zaehler,1);
	}
	/**
	 * Ganze Zahl abzeihen
	 * @param Zahl
	 */
	public void rem(int zaehler){
		this.add(zaehler*-1,1);
	}
	/**
	 * Aufgeteilten Bruch addieren
	 * @param zaehler
	 * @param nenner
	 */
	public void add(int zaehler,int nenner){
		Bruch temp = new Bruch(zaehler,nenner);
		this.add(this,temp);
	}
	/**
	 * Aufgeteilten Bruch abzeiehn
	 * @param zaehler
	 * @param nenner
	 */
	public void rem(int zaehler,int nenner){
		this.add(zaehler*-1,nenner);
	}
	/**
	 * Main - Methode
	 * zum Testen der Klasse
	 * @param args
	 */
	public static void main(String[] args) {
		Bruch b = new Bruch(1,1);
		b.add(2);
		b.rem(2);
		b.rem(1,1);
		b.print();
		b.add(1);
		b.print();
		b.multi(5);
		b.multi(5);
		b.print();
		b.multi(1,5);
		b.print();
		b.durch(5);
		b.print();
		b.kuerzen();
		b.print();
		b.add(24);
		b.durch(5);
		b.kuerzen();
		b.print();
	}
	/**
	 * Konstrukor mit Zaehler und Nenner
	 * @param zaehler
	 * @param nenner
	 */
	public Bruch(int zaehler, int nenner) {
		this.zaehler = zaehler;
		this.nenner = nenner;
	}
	/**
	 * Ganzen Bruch addieren
	 * @param Bruch
	 */
	public void add(Bruch b2){
		this.add(b2.zaehler,b2.nenner);
	}
	/**
	 * Ganzen Bruch abziehen
	 * @param Bruch
	 */
	public void rem(Bruch b2){
		this.add(b2.zaehler*-1,b2.nenner);
	}
	/**
	 * 2 Br�che miteinander addieren und zur�ckgeben
	 * @param Bruch 1
	 * @param Bruch 2
	 * @return addierter Bruch
	 */
	public Bruch add(Bruch b1, Bruch b2){
		b1.zaehler*=b2.nenner; //Auf gleichen Nenner bringen
		b1.nenner*=b2.nenner;
		b2.zaehler*=b1.nenner;
		b2.nenner*=b1.nenner;
		b1.zaehler+=b2.zaehler;
		return b1;
	}
	/**
	 * 2 Br�che voneinander abziehen
	 * @param b1
	 * @param b2
	 * @return
	 */
	public Bruch rem(Bruch b1, Bruch b2){
		b2.zaehler*=-1;
		this.add(b1,b2);
		return b1;
	}
	/**
	 * mit ganzem Bruch multiplizieren
	 * @param b2
	 */
	public void multi(Bruch b2){
		this.multi(this,b2);
	}
	/**
	 * Aufgeiteilten Bruch multiplizieren
	 * @param zaehler
	 * @param nenner
	 */
	public void multi(int zaehler, int nenner){
		Bruch temp = new Bruch(zaehler,nenner);
		this.multi(this,temp);
	}
	/**
	 * Nur mit einem Zaehler multiplizieren
	 * @param zaehler
	 */
	public void multi(int zaehler){
		Bruch temp = new Bruch(zaehler,1);
		this.multi(this,temp);
	}
	/**
	 * 2 Br�che miteinander multiplizieren
	 * @param b1
	 * @param b2
	 * @return multiplizierten Bruch
	 */
	public Bruch multi(Bruch b1, Bruch b2){
		b1.nenner*=b2.nenner;
		b1.zaehler*=b2.zaehler;
		return b1;
	}
	/**
	 * Bruch ausgeben
	 */
	public void print(){
		System.out.println(zaehler+"/"+nenner);
	}
	/**
	 * Durch aufgeteilten Bruch dividieren
	 * @param zaehler
	 * @param nenner
	 */
	public void durch(int zaehler, int nenner){
		Bruch temp = new Bruch(nenner,zaehler);
		this.multi(this,temp);
	}
	/**
	 * Durch Zaehler dividieren
	 * @param zaehler
	 */
	public void durch(int zaehler){
		this.durch(zaehler,1);
	}
	/**
	 * Durch Bruch dividieren
	 * @param b1
	 */
	public void durch(Bruch b1){
		this.durch(b1.zaehler,b1.nenner);
	}
	/**
	 * 2 Br�che miteinander dividieren
	 * @param b1
	 * @param b2
	 * @return
	 */
	public Bruch durch(Bruch b1,Bruch b2){
		umkehren(b2);
		return this.multi(b1,b2);
	}
	/**
	 * Methode um den Kehrwert eines Bruchs zu erzeugen
	 * @param b
	 */
	public static void umkehren(Bruch b){
		int temp;
		temp = b.zaehler;
		b.zaehler=b.nenner;
		b.nenner = temp;
	}
	/**
	 * Konstruktor mit nur dem Zaehler
	 * @param zaehler
	 */
	public Bruch(int zaehler) {
		this(zaehler,1);
	}
	/**
	 * Methode um Br�che zu k�rzen
	 */
	public void kuerzen(){
		boolean kuerzbar = true;
		int ggt = 0;
		while(kuerzbar==true){ //Solange der Bruch noch kuerzbar ist
			if(this.zaehler==this.nenner){ //Ist es 1 ganzes
				zaehler=1;
				nenner=1;
				kuerzbar = false;
			}
			for(int i = 2;i<=this.nenner&&i<=this.zaehler;i++) //Nach einem gemeinsamen Teiler suchen
				if(this.zaehler%i==0&&this.nenner%i==0){
					ggt=i; //Gtoesster gemeinsamer Teiler
				}
			if(ggt == 0){ //Habe ich einen ggt gefunden
				kuerzbar = false; //wenn nein
			}
			else{ //wenn ja
				zaehler/=ggt;
				nenner/=ggt;
				ggt=0;
			}
		}
	}
}
