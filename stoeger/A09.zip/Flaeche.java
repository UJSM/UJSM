package stoeger;
/**
 * Abstrakte Klasse fuer A09
 * @author Michael Stoeger
 * @version 17.11.2013
 */
public abstract class Flaeche {
	/**
	 * Gibt den Typ der Flaeche als String zurueck
	 * wie Kreis, Dreieck,....
	 * @return name
	 */
	public abstract String name();
	/**
	 * Gibt Daten ueber die Flaeche als String zurueck
	 * @return definition
	 */
	public abstract String definition();
	/**
	 * Gibt den Umfang als Double zurueck
	 * @return umfang
	 */
	public abstract double umfang();
	/**
	 * Gibt die Flaeche als Double zurueck
	 * @return flaeche
	 */
	public abstract double flaeche();
	public String toString(){
		System.out.println("Kein toString vorhanden --FEHLER");
		return null;
	}
}
