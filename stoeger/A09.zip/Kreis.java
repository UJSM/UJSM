package stoeger;
/**
 * Klasse fuer Kreise
 * Erbt von Flaeche
 * @author Michael Stoeger
 * @version 17.11.2013
 */
public class Kreis extends Flaeche{
	private double radius;
	private double x;
	private double y;
	/**
	 * Getter fuer X
	 * @return x
	 */
	public double getX() {
		return x;
	}
	/**
	 * Setter fuer X
	 * @param x
	 */
	public void setX(double x) {
		this.x = x;
	}
	/**
	 * Getter fuer Y
	 * @return y
	 */
	public double getY() {
		return y;
	}
	/**
	 * Setter fuer Y
	 * @param y
	 */
	public void setY(double y) {
		this.y = y;
	}
	@Override
	/**
	 * {@link Flaeche#name()}
	 */
	public String name() {
		return "Kreis";
	}
	@Override
	/**
	 * {@link Flaeche#definition()}
	 */
	public String definition() {
		return "Radius r="+this.radius+ " X="+x+" Y="+y;
	}
	@Override
	/**
	 * {@link Flaeche#umfang()}
	 */
	public double umfang() {
		return 2*Math.PI*radius;
	}
	@Override
	/**
	 * {@link Flaeche#flaeche()}
	 */
	public double flaeche() {
		return Math.PI*radius*radius;
	}
	/**
	 * Konstruktor mit Radius als Double
	 * @param r
	 */
	public Kreis(double r){
		this(r,0,0);
	}
	/**
	 * Standardkonstruktor
	 */
	public Kreis(){
		this(0);
	}
	/**
	 * Getter fuer Radius
	 * @return r
	 */
	public double getRadius() {
		return radius;
	}
	/**
	 * Setter fuer Radius
	 * @param radius
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}
	/**
	 * Konstruktor mit Radius, x und y
	 * @param r
	 * @param x
	 * @param y
	 */
	public Kreis(double r, double x, double y){
		radius=r;
		this.x=x;
		this.y=y;
	}
}
