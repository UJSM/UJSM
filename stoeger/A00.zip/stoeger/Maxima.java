/**
 * Diese Klasse kann das Maximum von 2,3,5 und 10 Zahlen bestimmen
 * @author Michael St�ger
 * @version 15.9.2013
 */
public class Maxima {
	/**
	 * Diese Methode berechnet das Maximum von 2 Zahlen
	 * @param z1 -> 1. Testzahl
	 * @param z2 -> 2. Testzahl
	 * @return Maximum beider Zahlen
	 */
	public static int max(int z1, int z2){
		if(z1>z2)
			return z1; //Wenn z1 groesser ist
		else
			return z2; //sonst
	}
	/**
	 * Diese Methode berechnet das Maximum von 3 Zahlen
	 * @param z1 -> 1. Testzahl
	 * @param z2 -> 2. Testzahl
	 * @param z3 -> 3. Testzahl
	 * @return Maximum aller 3 Zahlen
	 */
	public static int max(int z1, int z2, int z3){
		return max(max(z1,z2),z3); //Groesste zurueckgeben
	}
	/**
	 * Diese Methode berechnet das Maximum von 5 Zahlen
	 * @param z1 -> 1. Testzahl
	 * @param z2 -> 2. Testzahl
	 * @param z3 -> 3. Testzahl
	 * @param z4 -> 4. Testzahl
	 * @param z5 -> 5. Testzahl
	 * @return Maximum aller 5 Zahlen
	 */
	public static int max(int z1,int z2,int z3,int z4,int z5){
		return max(max(z1,z2,z3),max(z4,z5)); //Groesste zurueckgeben
	}
	/**
	 * Diese Methode berechnet das Maximum von 10 Zahlen
	 * @param z1 -> 1. Testzahl
	 * @param z2 -> 2. Testzahl
	 * @param z3 -> 3. Testzahl
	 * @param z4 -> 4. Testzahl
	 * @param z5 -> 5. Testzahl
	 * @param z6 -> 6. Testzahl
	 * @param z7 -> 7. Testzahl
	 * @param z8 -> 8. Testzahl
	 * @param z9 -> 9. Testzahl
	 * @param z10 -> 10. Testzahl
	 * @return Maximum aller 10 Zahlen
	 */
	public static int max(int z1, int z2, int z3, int z4, int z5, int z6, int z7, int z8, int z9, int z10){
		return max(max(z1,z2,z3,z4,z5),max(z6,z7,z8,z9,z10)); //Groesste zurueckgeben
	}
	/**
	 * Main Methode -> fuer Programmtests
	 * @param args
	 */
	public static void main(String[] args){
		int[] z = new int[10]; //Array fuer 10 Werte
		for(int i = 0;i<z.length;i++) //Ganzes Array fuellen
			z[i] = (int)(Math.random()*100); //Mit Zufallszahlen von 0 bis 100
		System.out.println("Das Maximum von "+z[0]+" und "+z[1]+" ist: "+max(z[0],z[1])); //Test fuer 2 Zahlen
		System.out.println("Das Maximum von "+z[0]+", "+z[1]+" und "+z[2]+" ist: "+max(z[0],z[1],z[2])+"."); //Test fuer 3 Zahlen
		System.out.println("Das Maximum von "+z[0]+", "+z[1]+", "+z[2]+", "+z[3]+" und "+z[4]+" ist: "+max(z[0],z[1],z[2],z[3],z[4])+"."); //Test fuer 5 Zahlen
		System.out.print("Das Maximum von "+z[0]+", "+z[1]+", "+z[2]+", "+z[3]+", "+z[4]+", "+z[5]+", "+z[6]+", "+z[7]+", "+z[8]+" und "+z[9]+" ist: "+max(z[0],z[1],z[2],z[3],z[4],z[5],z[6],z[7],z[8],z[9])+"."); //Test fuer 10 Zahlen
	}
}
