package stoeger;
/**
 * Klasse um mit Komplexen Zahlen zu rechnen
 * @author Michael St�ger
 * @version 12.10.2013
 */
public class Cplx {
	private double real;
	private double cplx;
	/**
	 * @param real
	 * @param cplx
	 */
	public Cplx(double real,double cplx){
		this.real = real;
		this.cplx = cplx;
	}
	/**
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static Cplx add(Cplx c1, Cplx c2){
		return new Cplx(c1.getReal()+c2.getReal(),c1.getCplx()+c2.getCplx());
	}
	/**
	 * @param real
	 * @return
	 */
	public Cplx add(double real){
		this.real+=real;
		return this;
	}
	/**
	 * @param real
	 * @param cplx
	 * @return
	 */
	public Cplx add(double real,double cplx){
		this.real+=real;
		this.cplx+=cplx;
		return this;
	}
	/**
	 * @param k
	 * @return
	 */
	public Cplx add(Cplx k){
		this.real+=k.getReal();
		this.cplx+=k.getCplx();
		return this;
	}
	/**
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static Cplx rem(Cplx c1,Cplx c2){
		return new Cplx(c1.getReal()-c2.getReal(),c1.getCplx()-c2.getCplx());
	}
	/**
	 * @param real
	 * @return
	 */
	public Cplx rem(double real){
		return this.add(real*-1);
	}
	/**
	 * @param real
	 * @param cplx
	 * @return
	 */
	public Cplx rem(double real,double cplx){
		this.real-=real;
		this.cplx-=cplx;
		return this;
	}
	/**
	 * @param c
	 * @return
	 */
	public Cplx rem(Cplx c){
		this.real-=c.getReal();
		this.cplx-=c.getCplx();
		return this;
	}
	/**
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static Cplx multi(Cplx c1, Cplx c2){
		return new Cplx((c1.getReal()*c2.getReal()-c1.getCplx()*c2.getCplx()),(c1.getReal()*c2.getCplx()-c1.getCplx()*c2.getReal())); //direkt neues Objekt zur�ckgeben
	}
		/**
	 * 
	 * @param real
	 * @return
	 */
	public Cplx multi(double real){
		Cplx temp = multi(this,new Cplx(real,1));
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Multipliziert mit echter und komplexer Zahl
	 * @param real
	 * @param cplx
	 * @return this
	 */
	public Cplx multi(double real,double cplx){
		Cplx temp = multi(this,new Cplx(real,cplx));
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * @param c
	 * @return
	 */
	public Cplx multi(Cplx c){
		Cplx temp = multi(this,c);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Dividiert 2 Objekte und gibt ein neues zur�ck(ver�ndert Ursprung nicht)
	 * @param c1
	 * @param c2
	 * @return neues c
	 */
	public static Cplx durch(Cplx c1, Cplx c2){
		double real = c1.getReal()*c2.getReal()+c1.getCplx()*c2.getCplx(); //Echte Zahl brechnen
		double newnenner=c2.getReal()*c2.getReal()+c2.getCplx()*c2.getCplx();
		if(newnenner!=0){ //Wird durch 0 dividiert
			real/=newnenner;
			double cplx = c1.getCplx()*c2.getReal()-c1.getReal()*c2.getCplx(); //Komplexe Zahl berechnen
			double newnennercplx=c2.getReal()*c2.getReal()+c2.getCplx()*c2.getCplx();
			if(newnennercplx!=0){ //Wird durch 0 dividiert
				cplx/=newnennercplx;
				return new Cplx(real,cplx); //Neues Objekt generieren
			}
			else
				return new Cplx(0,0);
			
		}
		else
			return new Cplx(0,0);
		
	}
	/**
	 * Dividiert durch eine Komplexe Zahl
	 * @param real
	 * @return this
	 */
	public Cplx durch(double real){
		Cplx temp = new Cplx(real,1);
		temp = durch(this,temp);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Dividiert durch eine echte und eine komplexe Zahl
	 * @param real
	 * @param cplx
	 * @return this
	 */
	public Cplx durch(double real,double cplx){
		Cplx temp = new Cplx(real,cplx);
		temp = durch(this,temp);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Dividiert durch ein Objekt
	 * @param c
	 * @return this
	 */
	public Cplx durch(Cplx c){
		Cplx temp = durch(this,c);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Holt reelle Zahl
	 * @return real
	 */
	public double getReal() {
		return real;
	}
	/**
	 * Setzte reelle Zahl
	 * @param real
	 */
	public void setReal(double real) {
		this.real = real;
	}
	/**
	 * Holt Komplexe Zahl
	 * @return Komplex
	 */
	public double getCplx() {
		return cplx;
	}
	/**
	 * Setter f�r Komplexe Zahl
	 * @param cplx
	 */
	public void setCplx(double cplx) {
		this.cplx = cplx;
	}
	/**
	 * Gibt die Zahlen aus
	 */
	public void print(){
		this.print(false);
	}
	/**
	 * Standardkonstruktor
	 */
	public Cplx(){
		this(0,0);
	}
	/**
	 * Konstruktor mit reeller Zahl
	 * @param real
	 */
	public Cplx(double real){
		this(real,0);
	}
	/**
	 * Ausgabe mit Runden
	 * @param runden -> boolean
	 */
	public void print(boolean x){
		if(x==true)
			System.out.println(Math.round(this.real*100d)/100d+" + "+Math.round(this.cplx*100d)/100d+"i");
		else
			System.out.println(this.real+" + "+this.cplx+"i");
	}
}
