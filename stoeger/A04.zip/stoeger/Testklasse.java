package stoeger;
/**
 * Testklasse f�r Komplex
 * @author Michael St�ger
 * @version 17.10.2013
 */
public class Testklasse {
	/**
	 * Main Methode
	 * Testet Klasse Cplx
	 * @param args
	 */
	public static void main(String[] args) {
		Cplx x = new Cplx(2,2);//Neues Objekt
		x.print(); //Test ausgabe
		x.add(1); //Alle add Methoden Testen
		x.print(); //Immer zwischenausgabe
		x.add(1,1);
		x.print();
		x.add(new Cplx(1,1));
		x.print();
		x.rem(1); //Alle rem Methoden testen
		x.rem(2,2);
		x.rem(new Cplx(2,2));
		x.print();
		x.add(1,1);
		x.print();
		x.multi(2,4); //Alle multi Methoden Testen
		x.print();
		x.multi(5);
		x.print();
		x.multi(new Cplx(3,4));
		x.print();
		x.durch(new Cplx(3,4)); //Alle durch Methoden Testen
		x.print();
		x.durch(5);
		x.print();
		x.print(true); //Runden Testen
		x.durch(2,5);
		x.print();
		x.print(true);
	}

}
