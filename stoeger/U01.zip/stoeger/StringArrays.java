package stoeger;
/**
 * U01 - Klasse
 * @author Michael St�ger
 * @version 23.09.2013
 */
public class StringArrays {
	private String[] a;
	private static int size = 3;
	/**
	 * F�gt ein Feld zum Array hinzu
	 * @param s -> String hinzuzuf�gen
	 */
	public void add(String s){
		String ss[] = new String[a.length+1];
		for(int i = 0;i<a.length;i++)
			ss[i]=a[i];
		ss[ss.length]=s;
		a = ss;
	}
	/**
	 * Mehrere Felder hinzuf�gen
	 * @param s -> Array der hinzuzuf�genden Werte
	 */
	public void add(String[] s){
		String ss[] = new String[a.length+s.length];
		for(int i = 0;i<a.length;i++)
			ss[i]=a[i];
		for(int i=a.length;i+3<ss.length+a.length;i++)
			ss[i]=s[i-a.length];
		a=ss;
	}
	/**
	 * Expliziten String entfernen
	 * @param s -> zu entfernender String
	 */
	public void remove(String s){
		String[] ss = new String[a.length-1];
		int y  = 0;
		for(int i=0;i<ss.length;i++,y++){
			if(a[y]==s)
				y++;
			ss[i]=a[y];
		}
		a=ss;
	}
	/**
	 * Anzahl der zu entfernenden Felder
	 * @param i
	 */
	public void remove(int i){
		String ss[] = new String[a.length-i];
		for(int y=0;y<ss.length;y++)
			ss[y]=a[y];
		a=ss;
	}
	/**
	 * Einzelnen Wert aus dem Array holen
	 * @param i Stelle des zu holenden Werts
	 * @return Stelle
	 */
	public String get(int i){
		return a[i];
	}
	/**
	 * Bestimmte Stelle im Array setzen
	 * @param i Stelle
	 * @param s String zu setzen
	 */
	public void set(int i,String s){
		if(i>=a.length){
			String ss[] = new String[a.length+1];
			for(int x = 0;x<a.length;x++)
				ss[x]=a[x];
			ss[ss.length-1]=s;
			a=ss;
		}
		else{
			a[i-1]=s;
		}
	}
	/**
	 * Alle Felder ausgeben
	 */
	public void print(){
		for(int i = 0;i<a.length;i++)
			System.out.println("Das "+(i+1)+". Feld: "+a[i]+".");
	}
	/**
	 * Bestimmte Anzahl an Feldern ausgeben
	 * @param anzahl
	 */
	public void print(int anzahl){
		for(int i = 0;i<a.length&&i<anzahl&&anzahl>0;i++)
			System.out.println("Das "+(i+1)+". Feld: "+a[i]+".");
	}
	/**
	 * Bestimmte Stellen im Array ausgeben
	 * @param start
	 * @param end
	 */
	public void print(int start,int end){
		for(int i = start-1;i<a.length&&i<end&&end>0&&start>=0;i++)
			System.out.println("Das "+(i+1)+". Feld: "+a[i]+".");
	}
	/**
	 * Konstruktor mit L�nge
	 * @param anzahl
	 */
	public StringArrays(int anzahl){
		a = new String[anzahl];
	}
	/**
	 * Adresse des Arrays holen
	 * @return
	 */
	public String[] getA() {
		return a;
	}
	/**
	 * Adresse des Arrays ersetzen
	 * @param a
	 */
	public void setA(String[] a) {
		this.a = a;
	}
	/**
	 * Konstruktor mit gegebenem Array
	 * @param a
	 */
	public StringArrays(String[] a) {
		this.a = a;
	}
	/**
	 * Standardkonstruktor
	 * size -> konstante: oben deffiniert
	 */
	public StringArrays(){
		a = new String[size];
	}
	/**
	 * Main-Methode
	 * zum Testen der Klasse
	 * @param args
	 */
	public static void main(String[] args){
		StringArrays x = new StringArrays();
		x.print();
		x.set(1, "Feld");
		x.print();
		x.print(1);
		x.print(2,3);
		String[] s = new String[4];
		s[0]="erweiterung";
		x.add(s);
		x.print();
		x.remove(3);;
		x.print();
		x.remove("erweiterung");
		x.print();
	}
}
