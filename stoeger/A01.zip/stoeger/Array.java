package stoeger;
/**
 * Klasse um den Umgang mit Arrays zu �ben
 * @author Michael St�ger
 * @version 16.09.2013
 */
public class Array {
	private double[] arr;
	private static final int size = 4;
	/**
	 * @return Adresse des Arrays
	 */
	public double[] getArr() {
		return arr;
	}
	/**
	 * @param arr -> Adresse des Arrays setzen
	 */
	public void setArr(double[] arr) {
		this.arr = arr;
	}
	/**
	 * Konstruktor, wenn Array gegeben ist
	 * @param Array(Adresse)
	 */
	public Array(double[] arr) {
		this.arr = arr;
	}
	/**
	 * Standardkonstruktor
	 * -> f�r Anpassungen: Konstante �ndern
	 */
	public Array() {
		this(size);
	}
	/**
	 * Konstruktor, wenn Gr��e gegeben ist
	 * @param size
	 */
	public Array(int size) {
		arr = new double[size];
	}
	/**
	 * Array ausgeben
	 */
	public void print(){
		for(int i = 0;i<arr.length;i++)
			System.out.println(arr[i]);
	}
	/**
	 * Array ausgeben
	 * ->nur bestimmte L�nge
	 * @param length
	 */
	public void print(int length){
		for(int i = 0;i<arr.length&&i<length;i++)
			System.out.println(arr[i]);
	}
	/**
	 * Array Ausgeben
	 * ->mit Angabe von Beginn und Ende
	 * @param start
	 * @param end
	 */
	public void print(int start, int end){
		start--;
		for(;start<end&&start<arr.length&&start>=0&&end>0;start++)
			System.out.println(arr[start]);
	}
	/**
	 * Main Mathode - f�r Tests
	 * @param args
	 */
	public static void main(String[] args){
		Array a = new Array();
		a.init();
		System.out.println("Array mit 4 Feldern:");
		a.print();
		a.remove(1);
		System.out.println("Array mit 3 Feldern:");
		a.print();
		a.add(2);;
		System.out.println("Array mit 5 Feldern:");
		a.print();
		System.out.println("Ausgabe: Start bei 2 Ende bei 5");
		a.print(2,5);
		System.out.println("Ausgabe: Laenge = 2");
		a.print(2);
	}
	/**
	 * Felder des Arrays entfernen
	 * @param rem -> Felder zu entfernen
	 */
	public void remove(int rem){
		double[] x = new double[arr.length-rem]; //Neues Array erstellen
		for(int i = 0;i<x.length;i++)
			x[i] = arr[i]; //Werte kopieren
		arr = x; //Adresse ersetzen
	}
	/**
	 * Array vergr��ern
	 * @param add -> Felder hinzuzuf�gen
	 */
	public void add(int add){
		double[] newarr = new double[arr.length+add]; //Neues Array erstellen
		for(int i = 0;i<arr.length;i++)
			newarr[i] = arr[i]; //Werte kopieren
		arr = newarr; //Adresse ersetzen
		this.init(); //Werte auff�llen
	}
	/**
	 * Methode um die Felder eines Arrays aufzuf�llen
	 * ->Quadrat des Indexes
	 */
	public void init(){
		for(int i=0;i<arr.length;i++)
			arr[i]=i*i;
	}
}
