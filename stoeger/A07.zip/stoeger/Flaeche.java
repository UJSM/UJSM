package stoeger;
/**
 * Interface fuer A07
 * @author Michael Stoeger
 * @version 17.11.2013
 */
public interface Flaeche {
	/**
	 * Gibt den Typ der Flaeche als String zurueck
	 * wie Kreis, Dreieck,....
	 * @return name
	 */
	public String name();
	/**
	 * Gibt Daten ueber die Flaeche als String zurueck
	 * @return definition
	 */
	public String definition();
	/**
	 * Gibt den Umfang als Double zurueck
	 * @return umfang
	 */
	public double umfang();
	/**
	 * Gibt die Flaeche als Double zurueck
	 * @return flaeche
	 */
	public double flaeche();
}
