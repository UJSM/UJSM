package stoeger;
/**
 * Klasse zum Testen von A07
 * @author Michael Stoeger
 * @version 17.11.2013
 */
public class Testklasse {
	/**
	 * Gibt Informationen ueber eine Flaeche aus
	 * @param a -> Flaeche
	 */
	public static void ausgabe(Flaeche a){
		System.out.println("Die Flaeche ist ein "+a.name()+".");
		System.out.println("Definition: ");
		System.out.println(a.definition());
	}
	/**
	 * Gibt ein Array mit 3 verschiedenen erzeugten Flaechen zurueck
	 * @return erzeugteFlaechen[3]
	 */
	public static Flaeche[] erzeugeFlaechen(){
		Flaeche[] a = new Flaeche[3];
		a[0] = new Kreis(5);
		a[1] = new Dreieck(0,0,3,0,3,4);
		a[2] = new Rechteck(0,0,5,10);
		return a;
	}
	/**
	 * Main Methode
	 * @param args
	 */
	public static void main(String[] args){
		Flaeche a[] = erzeugeFlaechen();
		for(int i=0;i<a.length;i++)
			ausgabe(a[i]);
	}
}
