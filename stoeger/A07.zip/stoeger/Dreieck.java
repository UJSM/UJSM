package stoeger;
/**
 * Klasse fuer Dreiecke
 * Implementiert Flaeche
 * 
 * Laengen ABC werden automatisch berechnet --->!!!!!! deswegen keine Setter
 * @author Michael Stoeger
 * @version 17.11.2013
 */
public class Dreieck implements Flaeche{
	private double a; //ABC nur hilfsmittel zur schnelleren Berechnung
	private double b;
	private double c;
	private double p1_x; //Punkt 1
	private double p1_y;
	private double p2_x; //Punkt 2
	private double p2_y;
	private double p3_x; //Punkt 3
	private double p3_y;
	@Override
	/**
	 * {@link Flaeche#name()}
	 */
	public String name() {
		return "Dreieck";
	}
	@Override
	/**
	 * {@link Flaeche#definition()}
	 */
	public String definition() {
		return "Seite a="+a+" Seite b="+b+ " Seite c="+c;
	}
	@Override
	/**
	 * {@link Flaeche#umfang()}
	 */
	public double umfang() {
		return a+b+c;
	}
	@Override
	/**
	 * {@link Flaeche#flaeche()}
	 */
	public double flaeche() {
		double s = (a+b+c)/2; //Heron
		return Math.sqrt(s*(s-a)*(s-b)*(s-c));
	}
	/**
	 * Standardkonstruktor
	 */
	public Dreieck(){
		this(0,0,0,0,0,0);
	}
	/**
	 * Getter fuer A
	 * @return a
	 */
	public double getA() {
		return a;
	}
	/**
	 * Getter fuer B
	 * @return b
	 */
	public double getB() {
		return b;
	}
	/**
	 * Getter fuer C
	 * @return c
	 */
	public double getC() {
		return c;
	}
	/**
	 * Getter fuer Punkt 1 X
	 * @return p1_x
	 */
	public double getP1_x() {
		return p1_x;
	}
	/**
	 * Setter fuer p1 x
	 * @param p1_x
	 */
	public void setP1_x(double p1_x) {
		this.p1_x = p1_x;
		genABC();
	}
	/**
	 * Getter fuer p1_y
	 * @return y
	 */
	public double getP1_y() {
		return p1_y;
	}
	/**
	 * Setter fuer p1 y
	 * @param p1_y
	 */
	public void setP1_y(double p1_y) {
		this.p1_y = p1_y;
		genABC();
	}
	/**
	 * Getter fuer p2_x
	 * @return p2_x
	 */
	public double getP2_x() {
		return p2_x;
	}
	/**
	 * Setter fuer p2_x
	 * @param p2_x
	 */
	public void setP2_x(double p2_x) {
		this.p2_x = p2_x;
		genABC();
	}
	/**
	 * Getter fuer p2_y
	 * @return p2_y
	 */
	public double getP2_y() {
		return p2_y;
	}
	/**
	 * Setter fuer p2_y
	 * @param p2_y
	 */
	public void setP2_y(double p2_y) {
		this.p2_y = p2_y;
		genABC();
	}
	/**
	 * Getter fuer p3_x
	 * @return p3_x
	 */
	public double getP3_x() {
		return p3_x;
	}
	/**
	 * Setter fuer p3_x
	 * @param p3_x
	 */
	public void setP3_x(double p3_x) {
		this.p3_x = p3_x;
		genABC();
	}
	/**
	 * Getter fuer p3_y
	 * @return p3_y
	 */
	public double getP3_y() {
		return p3_y;
	}
	/**
	 * Setter fuer p3_y
	 * @param p3_y
	 */
	public void setP3_y(double p3_y) {
		this.p3_y = p3_y;
		genABC();
	}
	/**
	 * Konstruktor mit Punkten
	 * a,b,c werden automatisch neu berechnet
	 * @param p1_x
	 * @param p1_y
	 * @param p2_x
	 * @param p2_y
	 * @param p3_x
	 * @param p3_y
	 */
	public Dreieck(double p1_x, double p1_y, double p2_x, double p2_y, double p3_x, double p3_y) {
		this.p1_x = p1_x;
		this.p1_y = p1_y;
		this.p2_x = p2_x;
		this.p2_y = p2_y;
		this.p3_x = p3_x;
		this.p3_y = p3_y;
		this.genABC(); //Laengen abc berechnen
	}
	/**
	 * Die Attribute ABC werden erneut berechnet
	 * Dies ist nach jeder Punktaenderung notwendig und wird automatisch gemacht
	 */
	public void genABC(){
		double p1_p2_x = p1_x-p2_x;
		double p1_p2_y = p1_y-p2_y;
		a = Math.sqrt(p1_p2_x*p1_p2_x+p1_p2_y*p1_p2_y);
		//alte Variablen wiederbenutzen
		p1_p2_x = p2_x-p3_x;
		p1_p2_y = p2_y-p3_y;
		b = Math.sqrt(p1_p2_x*p1_p2_x+p1_p2_y*p1_p2_y);
		p1_p2_x = p3_x-p1_x;
		p1_p2_y = p3_y-p1_y;
		c = Math.sqrt(p1_p2_x*p1_p2_x+p1_p2_y*p1_p2_y);
	}
}