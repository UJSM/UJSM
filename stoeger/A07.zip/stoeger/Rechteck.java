package stoeger;
/**
 * Klasse fuer Rechtecke
 * Implementiert Flaeche
 * A + B werden AUTOMATISCH generiert und k�nnen deswegen nicht gesetzt werden
 * sie werden bei Aktualisierung der Punkte AUTOMATISCH neu berechnet
 * @author Michael Stoeger
 * @version 17.11.2013
 */
public class Rechteck implements Flaeche{
	private double a;
	private double b;
	private double lu_x; //LinksUnten X
	private double lu_y; //LinksUnten Y
	private double ro_x; //RechtsOben X
	private double ro_y; //RechtsOben Y
	@Override
	/**
	 * {@link Flaeche#name()}
	 */
	public String name() {
		return "Rechteck";
	}
	@Override
	/**
	 * {@link Flaeche#definition()}
	 */
	public String definition() {
		return "Hoehe a="+a+" Hoehe b="+b;
	}
	@Override
	/**
	 * {@link Flaeche#umfang()}
	 */
	public double umfang() {
		return a*2+b*2;
	}
	@Override
	/**
	 * {@link Flaeche#flaeche()}
	 */
	public double flaeche() {
		return a*b;
	}
	/**
	 * Konstruktor mit den Punkten LinksUnten und RechtsOben
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 */
	public Rechteck(double x1,double y1, double x2, double y2){
		lu_x=x1;
		lu_y=y1;
		ro_x=x2;
		ro_y=y2;
		genAB();
	}
	/**
	 * Standardkonstruktor
	 */
	public Rechteck(){
		this(0,0,0,0);
	}
	/**
	 * Getter fuer A
	 * @return a
	 */
	public double getA() {
		return a;
	}
	/**
	 * Getter fuer B
	 * @return b
	 */
	public double getB() {
		return b;
	}
	/**
	 * Diese Methode berechnet AB neu
	 */
	public void genAB(){
		a = ro_x - lu_x;
		b = ro_y - lu_y;
	}
	/**
	 * Getter fuer LinksUnten x
	 * @return lu_x
	 */
	public double getLu_x() {
		return lu_x;
	}
	/**
	 * Setter fuer LinksUnten x
	 * @param lu_x
	 */
	public void setLu_x(double lu_x) {
		this.lu_x = lu_x;
		genAB();
	}
	/**
	 * Gettter fuer lu_y
	 * @return lu_y
	 */
	public double getLu_y() {
		return lu_y;
	}
	/**
	 * Setter fuer lu_y
	 * @param lu_y
	 */
	public void setLu_y(double lu_y) {
		this.lu_y = lu_y;
		genAB();
	}
	/**
	 * Getter fuer ro_x
	 * @return ro_x
	 */
	public double getRo_x() {
		return ro_x;
	}
	/**
	 * Setter fuer ro_x
	 * @param ro_x
	 */
	public void setRo_x(double ro_x) {
		this.ro_x = ro_x;
		genAB();
	}
	/**
	 * Getter fuer ro_x
	 * @return ro_y
	 */
	public double getRo_y() {
		return ro_y;
	}
	/**
	 * Setter fuer ro_y
	 * @param ro_y
	 */
	public void setRo_y(double ro_y) {
		this.ro_y = ro_y;
		genAB();
	}
}
