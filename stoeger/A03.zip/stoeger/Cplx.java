package stoeger;
/**
 * Klasse um mit Komplexen Zahlen zu rechnen
 * @author Michael St�ger
 * @version 12.10.2013
 */
public class Cplx {
	private double real;
	private double cplx;
	/**
	 * @param real
	 * @param cplx
	 */
	public Cplx(double real,double cplx){
		this.real = real;
		this.cplx = cplx;
	}
	/**
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static Cplx add(Cplx c1, Cplx c2){
		return new Cplx(c1.getReal()+c2.getReal(),c1.getCplx()+c2.getCplx());
	}
	/**
	 * @param real
	 * @return
	 */
	public Cplx add(double real){
		this.real+=real;
		return this;
	}
	/**
	 * @param real
	 * @param cplx
	 * @return
	 */
	public Cplx add(double real,double cplx){
		this.real+=real;
		this.cplx+=cplx;
		return this;
	}
	/**
	 * @param k
	 * @return
	 */
	public Cplx add(Cplx k){
		this.real+=k.getReal();
		this.cplx+=k.getCplx();
		return this;
	}
	/**
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static Cplx rem(Cplx c1,Cplx c2){
		return new Cplx(c1.getReal()-c2.getReal(),c1.getCplx()-c2.getCplx());
	}
	/**
	 * @param real
	 * @return
	 */
	public Cplx rem(double real){
		return this.add(real*-1);
	}
	/**
	 * @param real
	 * @param cplx
	 * @return
	 */
	public Cplx rem(double real,double cplx){
		this.real-=real;
		this.cplx-=cplx;
		return this;
	}
	/**
	 * @param c
	 * @return
	 */
	public Cplx rem(Cplx c){
		this.real-=c.getReal();
		this.cplx-=c.getCplx();
		return this;
	}
	/**
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static Cplx multi(Cplx c1, Cplx c2){
		return new Cplx((c1.getReal()*c2.getReal()-c1.getCplx()*c2.getCplx()),(c1.getReal()*c2.getCplx()-c1.getCplx()*c2.getReal())); //direkt neues Objekt zur�ckgeben
	}
		/**
	 * 
	 * @param real
	 * @return
	 */
	public Cplx multi(double real){
		Cplx temp = multi(this,new Cplx(real,1));
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Multipliziert mit echter und komplexer Zahl
	 * @param real
	 * @param cplx
	 * @return this
	 */
	public Cplx multi(double real,double cplx){
		Cplx temp = multi(this,new Cplx(real,cplx));
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * @param c
	 * @return
	 */
	public Cplx multi(Cplx c){
		Cplx temp = multi(this,c);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Dividiert 2 Objekte und gibt ein neues zur�ck(ver�ndert Ursprung nicht)
	 * @param c1
	 * @param c2
	 * @return neues c
	 */
	public static Cplx durch(Cplx c1, Cplx c2){
		double real = c1.getReal()*c2.getReal()+c1.getCplx()*c2.getCplx(); //Echte Zahl brechnen
		real/=c2.getReal()*c2.getReal()+c2.getCplx()*c2.getCplx();
		double cplx = c1.getCplx()*c2.getReal()-c1.getReal()*c2.getCplx(); //Komplexe Zahl berechnen
		cplx/=c2.getReal()*c2.getReal()+c2.getCplx()*c2.getCplx();
		return new Cplx(real,cplx); //Neues Objekt generieren
	}
	/**
	 * Dividiert durch eine Komplexe Zahl
	 * @param real
	 * @return this
	 */
	public Cplx durch(double real){
		Cplx temp = new Cplx(real,1);
		temp = durch(this,temp);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Dividiert durch eine echte und eine komplexe Zahl
	 * @param real
	 * @param cplx
	 * @return this
	 */
	public Cplx durch(double real,double cplx){
		Cplx temp = new Cplx(real,cplx);
		temp = durch(this,temp);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Dividiert durch ein Objekt
	 * @param c
	 * @return this
	 */
	public Cplx durch(Cplx c){
		Cplx temp = durch(this,c);
		this.real = temp.getReal();
		this.cplx = temp.getCplx();
		return this;
	}
	/**
	 * Holt reelle Zahl
	 * @return real
	 */
	public double getReal() {
		return real;
	}
	/**
	 * Setzte reelle Zahl
	 * @param real
	 */
	public void setReal(double real) {
		this.real = real;
	}
	/**
	 * Holt Komplexe Zahl
	 * @return Komplex
	 */
	public double getCplx() {
		return cplx;
	}
	/**
	 * Setter f�r Komplexe Zahl
	 * @param cplx
	 */
	public void setCplx(double cplx) {
		this.cplx = cplx;
	}
	/**
	 * Gibt die Zahlen aus
	 */
	public void print(){
		System.out.println(this.real+" + "+this.cplx+"i");
	}
	/**
	 * Standardkonstruktor
	 */
	public Cplx(){
		this(0,0);
	}
	/**
	 * Konstruktor mit reeller Zahl
	 * @param real
	 */
	public Cplx(double real){
		this(real,0);
	}
	/**
	 * Main-Methode
	 * zum Testen
	 * @param args
	 */
	public static void main(String[] args){
		Cplx x = new Cplx(2,2);
		x.print();
		x.add(2,1);
		x.print();
		x.add(0,1);
		x.durch(2,2);
		x.print();
		x.multi(1,5);
		x.print();
		x.rem(2,10);
		x.print();
	}
}
