package stoeger;

public class Testklasse {
	public static void main(String[] args){
		Vektor[] v = new Vektor[2];
		v[0] = new Vektor2(2,2);
		v[1] = new Vektor3(2,3,4);
		System.out.println("Vektor2 - Test - Anfang");
		System.out.println("Vektor2: "+v[0].toString());
		v[0].plus(new Vektor2(2,2));
		System.out.println("Vektor mit (2,2) dazu addiert: "+v[0].toString());
		v[0].mal(2);
		System.out.println("Mit 2 multipliziert: "+v[0].toString());
		System.out.println("Vektor2 - Test - Ende");
		//Trennlinie
		System.out.println("Vektor3 - Test - Anfang");
		System.out.println("Vektor3: "+v[1].toString());
		v[1].plus(new Vektor3(4,3,2));
		System.out.println("Vektor mit (4,3,2) dazu addiert: "+v[1].toString());
		v[1].mal(3);
		System.out.println("Mit 3 multipliziert: "+v[1].toString());
		System.out.println("Vektor3 - Test - Ende");
	}
}
