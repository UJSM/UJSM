package stoeger;
/**
 * Interface fuer A08 - Vektoren
 * @author Michael Stoeger
 * @version 18.11.2013
 */
public interface Vektor {
	/**
	 * Vektor mit einer Zahl multiplizieren
	 * @param z
	 * @return this
	 */
	public Vektor mal(double z);
	/**
	 * 2 Vektoren addieren
	 * @param Vektor
	 * @return this
	 */
	public Vektor plus(Vektor v);
}
