package stoeger;
/**
 * Vektor3 Klasse fuer A08
 * Implementiert Vektor
 * @author Michael Stoeger
 * @version 18.11.2013
 */
public class Vektor3 implements Vektor{
	private double x;
	private double y;
	private double z;
	@Override
	/**
	 * {@link Vektor#mal(double z)}
	 */
	public Vektor mal(double z) {
		this.x*=z;
		this.y*=z;
		this.z*=z;
		return this;
	}
	@Override
	/**
	 * {@link Vektor#plus(Vektor v)}
	 */
	public Vektor plus(Vektor v) {
		if(v instanceof Vektor3){
			this.x+=((Vektor3)v).getX();
			this.y+=((Vektor3)v).getY();
			this.z+=((Vektor3)v).getZ();
		}
		else
			System.out.println("Der uebergebene Vektor ist kein Vektor3!");
		return this;
	}
	/**
	 * Addiert 2 Vektoren
	 * @param v1
	 * @param v2
	 * @return v1+v2
	 */
	public static Vektor plus(Vektor v1, Vektor v2){
		Vektor v3 = new Vektor3();
		if(v1 instanceof Vektor3&&v2 instanceof Vektor3){
			((Vektor3) v3).setX(((Vektor3) v1).getX()+((Vektor3) v2).getX());
			((Vektor3) v3).setY(((Vektor3) v1).getY()+((Vektor3) v2).getY());
			((Vektor3) v3).setZ(((Vektor3) v1).getZ()+((Vektor3) v2).getZ());
		}
		else
			System.out.println("Einer der uebergebenen Vektoren ist kein Vektor3!");
		return v3;
	}
	/**
	 * Multipliziert einen Vektor mit einer Zahl
	 * @param v
	 * @param a
	 * @return v*a
	 */
	public static Vektor mal(Vektor v,double a){
		Vektor v3 = new Vektor3();
		if(v instanceof Vektor3){
			((Vektor3) v3).setX(((Vektor3) v).getX()*a);
			((Vektor3) v3).setY(((Vektor3) v).getY()*a);
			((Vektor3) v3).setZ(((Vektor3) v).getZ()*a);
		}
		else
			System.out.println("Der uebergebene Vektor ist kein Vektor3!");
		return v3;
	}
	/**
	 * Getter fuer X
	 * @return x
	 */
	public double getX() {
		return x;
	}
	/**
	 * Setter fuer X
	 * @param x
	 */
	public void setX(double x) {
		this.x = x;
	}
	/**
	 * Getter fuer Y
	 * @return y
	 */
	public double getY() {
		return y;
	}
	/**
	 * Setter fuer y
	 * @param y
	 */
	public void setY(double y) {
		this.y = y;
	}
	/**
	 * Getter fuer Z
	 * @return z
	 */
	public double getZ() {
		return z;
	}
	/**
	 * Setter fuer Z
	 * @param z
	 */
	public void setZ(double z) {
		this.z = z;
	}
	 /**
	  * Konstruktor fuer vollstaendigen Vektor3
	  * @param x
	  * @param y
	  * @param z
	  */
	public Vektor3(double x,double y,double z){
		this.x=x;
		this.y=y;
		this.z=z;
	}
	/**
	 * Standardkonstruktor
	 */
	public Vektor3(){
		this(0,0,0);
	}
	@Override
	public String toString() {
		return "("+this.x+", "+this.y+" ,"+this.z+")";
	}
}
