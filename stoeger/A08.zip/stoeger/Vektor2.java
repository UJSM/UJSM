package stoeger;
/**
 * Vektor2 Methode fuer A08
 * Implementiert Vektor
 * @author Michael Stoeger
 * @version 18.11.2013
 */
public class Vektor2 implements Vektor{
	private double x;
	private double y;
	@Override
	/**
	 * {@link Vektor#mal(double z)}
	 */
	public Vektor mal(double z) {
		this.x*=z;
		this.y*=z;
		return this;
	}
	@Override
	/**
	 * {@link Vektor#plus(Vektor v)}
	 */
	public Vektor plus(Vektor v) {
		Vektor temp = add(this,v);
		this.x=((Vektor2) temp).getX();
		this.y=((Vektor2) temp).getY();
		return this;
	}
	/**
	 * 2 Vektoren addieren
	 * @param v1
	 * @param v2
	 * @return v1+v2
	 */
	public static Vektor add(Vektor v1,Vektor v2){
		Vektor v3 = new Vektor2();
		if(v1 instanceof Vektor2&&v2 instanceof Vektor2){
			((Vektor2) v3).setX(((Vektor2) v1).getX()+((Vektor2) v2).getX());
			((Vektor2) v3).setY(((Vektor2) v1).getY()+((Vektor2) v2).getY());
		}
		else
			System.out.println("Einer der Uebergebenen Vektoren ist kein Vektor2!");
		return v3;
	}
	/**
	 * Vektor mit Zahl multiplizieren
	 * @param v1
	 * @param x
	 * @return v1*x
	 */
	public static Vektor mal(Vektor v1,double x){
		Vektor v3 = new Vektor2();
		if(v1 instanceof Vektor2){
			((Vektor2) v3).setX(((Vektor2) v1).getX());
			((Vektor2) v3).setY(((Vektor2) v1).getY());
			((Vektor2) v3).setX(((Vektor2) v3).getX()*x);
			((Vektor2) v3).setY(((Vektor2) v3).getY()*x);
		}
		else
			System.out.println("Der uebergebene Vektor ist kein Vektor2!");
		return v3;
	}
	/**
	 * Getter fuer X
	 * @return x
	 */
	public double getX() {
		return x;
	}
	/**
	 * Setter fuer X
	 * @param x
	 */
	public void setX(double x) {
		this.x = x;
	}
	/**
	 * Getter fuer Y
	 * @return y
	 */
	public double getY() {
		return y;
	}
	/**
	 * Setter fuer Y
	 * @param y
	 */
	public void setY(double y) {
		this.y = y;
	}
	@Override
	/**
	 * ToString fuer X,Y
	 * @return String
	 */
	public String toString() {
		return "("+this.x+", "+this.y+")";
	}
	/**
	 * Standardkonstruktor
	 */
	public Vektor2(){
		this(0,0);
	}
	/**
	 * Konstruktor mit X,Y
	 * @param x
	 * @param y
	 */
	public Vektor2(double x,double y){
		this.x=x;
		this.y=y;
	}
}