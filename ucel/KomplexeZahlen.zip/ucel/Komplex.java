/**
 * Package Ucel
 */
package ucel;

/**
 * Gesucht ist eine Klasse, in der die Grundrechnungsarten an Komplexen Zahlen angewendet werden k�nnen.
 * 
 * @author Johannes Ucel
 * @version 10.10.2013
 */
public class Komplex {
	private double real;
	private double imaginaer;

	/**
	 * @return Reale Zahl zur�ckgeben
	 */
	public double getReal() {
		return real;
	}

	/**
	 * @param real Ist die Reale Zahl
	 */
	public void setReal(double real) {
		this.real = real;
	}

	/**
	 * @return Imaginaere Zahl zur�ckgeben
	 */
	public double getImaginaer() {
		return imaginaer;
	}

	/**
	 * @param imaginaer Ist die Imaginaere Zahl
	 */
	public void setImaginaer(double imaginaer) {
		this.imaginaer = imaginaer;
	}

	/**
	 * Standardkonstruktor
	 */
	public Komplex() {
		this(0);
	}

	/**
	 * Konstruktor mit Real- und Imaginaerzahl als Parameter
	 * @param real Ist die Realzahl
	 * @param imaginaer Ist die Imaginaerzahl
	 */
	public Komplex(double real, double imaginaer) {
		this.real = real;
		this.imaginaer = imaginaer;
	}

	/**
	 * Konstruktor mit Realzahl als Parameter
	 * @param real Ist die Realzahl
	 */
	public Komplex(double real) {
		this(real, 1);
	}

	/**
	 * Methode zum Addieren einer Realzahl
	 * @param real Ist die Realzahl, die dazuaddiert wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex add(double real) {
		this.real += real;
		return this;
	}

	/**
	 * Methode zum Dazuaddieren von einer Real-und Imaginaerzahl
	 * @param real Ist die Realzahl
	 * @param imaginaer Ist die Imaginaerzahl
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex add(double real, double imaginaer) {
		this.real += real;
		this.imaginaer += imaginaer;
		return this;
	}

	/**
	 * Methode zum Dazuaddieren eines Objektes
	 * @param Objekt, welches dazuaddiert wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex add(Komplex k) {
		this.real += k.getReal();
		this.imaginaer += k.getImaginaer();
		return this;
	}

	/**
	 * Methode zum Addieren von zwei Objekten
	 * @param left Objekt, welches addiert wird
	 * @param right Objekt, welches dazuaddiert wird
	 * @return Es wird ein neues Objekt mit der Summe von den Realzahlen der beiden Objekten und den Imaginaerzahl zur�ckgegeben
	 */
	public static Komplex add(Komplex left, Komplex right) {
		return new Komplex((left.getReal() + right.getReal()),left.getImaginaer() + right.getImaginaer());
	}

	/**
	 * Methode zum Subtrahieren einer Realzahl
	 * @param real Ist die Realzahl, die abgezogen wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex remove(double real) {
		this.add(real * -1);
		return this;
	}

	/**
	 * Methode zum Subtrahieren einer Real-und einer Imaginaerzahl
	 * @param real Ist die Realzahl
	 * @param imaginaer Ist die Imaginaerzahl
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex remove(double real, double imaginaer) {
		this.add(real * -1, imaginaer * -1);
		return this;
	}

	/**
	 * Methode zum Subtrahieren eines Objektes
	 * @param k Objekt, welches abgezogen wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex remove(Komplex k) {
		this.real -= k.getReal();
		this.imaginaer -= k.getImaginaer();
		return this;
	}

	/**
	 * Methode zum Subtrahieren von zwei Objekten
	 * @param left Objekt, von dem was abgezogen wird
	 * @param right Objekt, welches subtrahiert wird
	 * @return Es wird ein neues Objekt mit der Differenz von den Realzahlen der beiden Objekten und den Imaginaerzahlen zur�ckgegeben
	 */
	public static Komplex remove(Komplex left, Komplex right) {
		return new Komplex((left.getReal() - right.getReal()),left.getImaginaer() - right.getImaginaer());
	}

	/**
	 * Methode zum Multiplizieren einer Realzahl
	 * @param real Ist die Realzahl, die dazumultipliziert wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex multi(double real) {
		this.multi(real, 1);
		return this;
	}

	/**
	 * Methode zum Multiplizieren einer Real-und einer Imaginaerzahl
	 * @param real Ist die Realzahl
	 * @param imaginaer Ist die Imaginaerzahl
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex multi(double real, double imaginaer) {
		double tempReal, tempImagin; //Zwischenspeicher
		tempReal = this.real * real - this.imaginaer * imaginaer;
		tempImagin = this.real * imaginaer + this.imaginaer * real;
		this.real = tempReal; //Wert �bergeben
		this.imaginaer = tempImagin; //Wert �bergeben
		return this;
	}

	/**
	 * Methode zum Dazumultiplizieren eines Objektes
	 * @param k Objekt, welches dazumultipliziert wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex multi(Komplex k) {
		this.multi(k.real, k.imaginaer);
		return this;
	}

	/**
	 * Methode zum Multiplizieren von zwei Objekten
	 * @param left Objekt, welches multipliziert wird
	 * @param right Objekt, welches dazumultipliziert wird
	 * @return Es wird ein neues Objekt zur�ckgegeben, welches das Produkt der Realzahlen und der Imaginaerzahlen als Parameter hat
	 */
	public static Komplex multi(Komplex left, Komplex right) {
		double real = left.getReal() * right.getReal() - left.getImaginaer() * right.getImaginaer();
		double imagin = left.getReal() * right.getImaginaer() + left.getImaginaer() * right.getReal();
		return new Komplex(real, imagin);
	}

	/**
	 * Methode zum Dividieren durch eine Realzahl
	 * @param real Ist die Realzahl, durch die dividiert wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex division(double real) {
		this.divison(real, 1);
		return this;
	}

	/**
	 * Methode zum Dividieren durch eine Real- und eine Imaginaerzahl
	 * @param real Ist die Realzahl
	 * @param imaginaer Ist die Imaginaerzahl
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex divison(double real, double imaginaer) {
		double tempReal, tempImagin;
		tempReal = (this.real * real + this.imaginaer * imaginaer) / (real * real + imaginaer * imaginaer);
		tempImagin = (this.imaginaer * real - this.real * imaginaer) / (real * real + imaginaer * imaginaer);
		this.real = tempReal;
		this.imaginaer = tempImagin;
		return this;
	}

	/**
	 * Methode zum Dividieren durch ein Objekt
	 * @param k Objekt, durch das dividiert wird
	 * @return Es wird eine Referenz auf das eigene Objekt zur�ckgegeben
	 */
	public Komplex division(Komplex k) {
		this.divison(k.real, k.imaginaer);
		return this;
	}

	/**
	 * Methode zum Dividieren von zwei Objekten
	 * @param left Objekt, welches dividiert wird
	 * @param right Objekt, durch das dividiert wird
	 * @return Es wird ein neues Objekt zur�ckgegeben, welches das Quotient der Realzahlen und der Imaginaerzahlen als Parameter hat
	 */
	public static Komplex divison(Komplex left, Komplex right) {
		double tempReal = (left.getReal() * right.getReal() + left.getImaginaer() * right.getImaginaer()) / (right.getReal() * right.getReal() + right.getImaginaer() * right.getImaginaer());
		double tempImagin = (left.getImaginaer() * right.getReal() - left.getReal() * right.getImaginaer()) / (right.getReal() * right.getReal() + right.getImaginaer() * right.getImaginaer());
		return new Komplex(tempReal, tempImagin);
	}

	/**
	 * Methode zum Ausgeben
	 */
	public void print() {
		if (imaginaer < 0) //Falls das Ergebnis negativ ist, wird das Vorzeichen bei der Ausgabe angepasst
			System.out.println(real + " - " + (-imaginaer) + "i");
		else
			System.out.println(real + " + " + imaginaer + "i");
	}

	/**
	 * Methode zum Testen
	 * @param args
	 */
	public static void main(String[] args) {
		Komplex k1 = new Komplex(5.0, 6.0);
		k1.add(2).add(3).multi(3).remove(3,2);
		k1.print();
		Komplex k2 = new Komplex(1, 2);
		Komplex k3 = new Komplex(4, 5);
		k3.division(k2);
		k3.print();
		k2.remove(k3).add(4);
		k2.print();
		Komplex k4 = multi (k2,k3);
		k4.print();
	}

}