/**
 * 
 */
package ucel;

/**
 * Gesucht ist eine Klasse, wo ein Array sowohl verkleinert als auch verg��ert werden kann. Anschlie�end sollen die Werte in den print-Methoden ausgegeben werden.
 * @author Johannes Ucel
 * @version 16.09.2013
 */

public class GrossKlein {
	private double[] feld;

	/**
	 * Standardkonstruktor 
	 * Das Array feld vom Datentyp double wird mit 5 Elementen erstellt
	 */
	public GrossKlein() {
		feld = new double[5];
	}

	/**
	 * In diesem Konstruktor wird auf das eigene Objekt verwiesen
	 * 
	 * @param feld Ist das Array-Attribut
	 */
	public GrossKlein(double[] feld) {
		this.feld = feld;
	}

	/**
	 * In diesem Konstruktor wird die Anzahl der Elemente des Arrays �ber einen Parameter bestimmt
	 * 
	 * @param size Ist die Anzahl der Elemente, die das Array erhalten soll
	 */
	public GrossKlein(int size) {
		feld = new double[size];
	}

	/**
	 * Diese Methode wird verwendet, um das Array zu vergr��ern
	 * 
	 * @param anzahl Gibt an, um wieviel das Array vergr��ert werden soll
	 */
	public void add(int anzahl) {
		double[] newFeld = new double[feld.length + anzahl];
		for (int i = 0; i < feld.length && anzahl > feld.length; i++) {
			newFeld[i] = feld[i];
		}
		feld = newFeld;
		this.initialisieren();
	}

	/**
	 * Diese Methode wird verwendet, um das Array zu verkleinern
	 * 
	 * @param anzahl Gibt an, um wieviel das Array verkleinert werden soll
	 */
	public void remove(int anzahl) {
		double[] newFeld = new double[feld.length - anzahl];
		for (int i = 0; i < newFeld.length && anzahl > newFeld.length; i++) {
			newFeld[i] = feld[i];
		}
		feld = newFeld;
		this.initialisieren();
	}

	/**
	 * Methode zum Ausgeben des Arrays
	 */
	public void print() {
		for (int i = 0; i < feld.length; i++)
			System.out.println(feld[i]);
	}

	/**
	 * Methode zum Ausgeben einer bestimmten Anzahl von Feldern des Arrays
	 * 
	 * @param anzahl Ist die Anzahl der auszugebenden Felder
	 */
	public void print(int anzahl) {
		for (int i = 0; i < anzahl && anzahl < feld.length; i++) {
			System.out.println(feld[i]);
		}
	}

	/**
	 * Methode zum Ausgeben des Array von start beginnend bis ende
	 * 
	 * @param start Gibt den Beginn der Ausgabe an
	 * @param ende Gibt das Ende der Ausgabe an
	 */
	public void print(int start, int ende) {
		start--; // start wird 1 abgezogen, damit beginnend von start bis
					// inklusive ende ausgegeben werden kann
		for (; start < feld.length && start < ende && start >= 0 && ende > 0; start++) {
			System.out.println(feld[start]);
		}
	}

	/**
	 * Methode zum Initialisieren
	 */
	public void initialisieren() {
		for (int i = 0; i < feld.length; i++)
			feld[i] = i * i;
	}

	/**
	 * Main-Methode zum Testen
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		GrossKlein a1 = new GrossKlein(10);
		a1.initialisieren();
		System.out.println("Unver�nderte Array mit 10 Feldern");
		a1.print();
		System.out.println("Das Array wird um 3 Felder vergr��ert");
		a1.add(3);
		a1.print();
		System.out.println("Das Array wird um 6 Felder verkleinert");
		a1.remove(6);
		a1.print();
		System.out.println("Es werde die ersten 5 Felder ausgegeben");
		a1.print(5);
		System.out.println("Es werden die Felder von 2 beginnend bis 5 ausgegeben");
		a1.print(2, 5);
	}

}
