package ucel;

/**
 * A00: Maxima Berechnen
 * In der Klasse Maximum sollen Methoden, die sich durch die Anzahl der Parameter unterscheiden, überladen werden.
 * In der Main-Methode werden die größten Werte ausgegeben
 * 
 * @author Johannes Ucel
 * @version 12.09.2013
 */
public class Maximum
{
    /**
     * In dieser Methode wird das Maximum von 2 Zahlen ermittelt
     * @param z1 Werte zum Vergleichen
     * @param z2 Werte zum Vergleichen
     * @return Das Maximum der Zahlen
     * @since 12.09.2013
     */
    public static int max (int z1, int z2){
        if (z1<z2)
            return z2;
        else
            return z1;
    }

    /**
     * In dieser Methode wird das Maximum von 3 Zahlen ermittelt
     * @param z1 Werte zum Vergleichen
     * @param z2 Werte zum Vergleichen
     * @param z3 Werte zum Vergleichen
     * @return Das Maximum der Zahlen
     * @since 12.09.2013
     */
    public static int max (int z1, int z2, int z3){
        return (max(max(z1,z2),z3));
    }

    /**
     * In dieser Methode wird das Maximum von 5 Zahlen ermittelt
     * @param z1 Werte zum Vergleichen
     * @param z2 Werte zum Vergleichen
     * @param z3 Werte zum Vergleichen
     * @param z4 Werte zum Vergleichen
     * @param z5 Werte zum Vergleichen
     * @return Das Maximum der Zahlen
     * @since 12.09.2013
     */
    public static int max (int z1, int z2, int z3, int z4, int z5){
        return (max(max(z1,z2,z3),z4,z5));
    }

    /**
     * In dieser Methode wird das Maximum von 10 Zahlen ermittelt
     * @param z1 Werte zum Vergleichen
     * @param z2 Werte zum Vergleichen
     * @param z3 Werte zum Vergleichen
     * @param z4 Werte zum Vergleichen
     * @param z5 Werte zum Vergleichen
     * @param z6 Werte zum Vergleichen
     * @param z7 Werte zum Vergleichen
     * @param z8 Werte zum Vergleichen
     * @param z9 Werte zum Vergleichen
     * @param z10 Werte zum Vergleichen
     * @return Das Maximum der Zahlen
     * @since 12.09.2013
     */
    public static int max (int z1, int z2, int z3, int z4, int z5, int z6, int z7, int z8, int z9, int z10){
        return (max(max(z1,z2,z3,z4,z5), max(z6, z7, z8, z9, z10)));
    }
    /**
     * @param args
     */
    public static void main(String[]args){
        int z1=1;
        int z2=9;
        int z3=4;
        int z4=7;
        int z5=14;
        int z6=22;
        int z7=28;
        int z8=10;
        int z9=3;
        int z10=17;
        System.out.println("Das Maximum von "+z1+" und "+z2+" ist "+max(z1,z2));
        System.out.println("Das Maximum von "+z1+", "+z2+" und "+z3+" ist "+max(z1,z2,z3));
        System.out.println("Das Maximum von "+z1+", "+z2+", "+z3+", "+z4+" und "+z5+" ist "+max(z1,z2,z3,z4,z5));
        System.out.println("Das Maximum von "+z1+", "+z2+", "+z3+", "+z4+", "+z5+", "+z6+", "+z7+", "+z8+", "+z9+" und "+z10+" ist "+max(z1,z2,z3,z4,z5,z6,z7,z8,z9,z10)); 
    }
}
